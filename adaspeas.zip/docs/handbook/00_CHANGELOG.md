---
doc_id: "DOC-CHANGELOG"
title: "Changelog"
project: "Adaspeas Docs"
owner: "TBD"
status: "DRAFT"
version: "v1"
last_updated: "2026-02-03"
---

# Changelog

## 2026-02-03
- Создан архив структуры документации (скелет).
- PRD импортирован в 01_product/PRD.md как канонический файл.

- 2026-02-03: Filled security/arch/ops/quality/planning docs from PRD v6; gate ARCHITECTURE_LOCKED unblocked.
